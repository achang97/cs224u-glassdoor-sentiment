import csv


files = [
	'airbnb-reviews.csv',
	'Amazon.glassdoor.csv',
	'apple-reviews.csv',
	'cisco-reviews.csv',
	'deloitte-reviews.csv',
	'facebook-reviews.csv',
	'google-reviews.csv',
	'jpmorgan-reviews.csv',
	'Macys.glassdoor.csv',
	'Microsoft.glassdoor.csv',
	'Nordstrom.glassdoor.csv',
	'oracle-reviews.csv',
	'salesforce-reviews.csv',
	'square-reviews.csv',
	'tesla-reviews.csv',
	'uber-reviews.csv',
	'ups-reviews.csv',
	'visa-reviews.csv',
	'yelp-reviews.csv',
]

def get_title(filename):
	if 'glassdoor' in filename:
		return filename[:filename.find('.')], True
	else:
		return filename[:filename.find('-')].capitalize(), False

if __name__ == '__main__':
	with open('glassdoor-data.csv', 'w') as newfile:
		writer = csv.writer(newfile)
		writer.writerow(['date', 'company', 'employee_title', 'review_title', 'pros', 'cons', 'advice_to_mgmt', 'rating_overall', 'rating_balance', 'rating_culture', 'rating_career', 'rating_comp', 'rating_mgmt'])
		for filename in files:
			company, needsFormatEdit = get_title(filename)
			with open(filename, 'r') as readfile:
				reader = csv.reader(readfile)
				
				seenHeader = False
				for line in reader:
					if not seenHeader:
						seenHeader = True
					else:
						if needsFormatEdit:
							line.pop(2)
							line.pop(2)
							line.pop(3)
							line.pop(3)
						line.insert(1, company)

						writer.writerow(line)

